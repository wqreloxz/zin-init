
#pragma once
#include <string>
namespace zin::audit {
bool init();
bool start();
bool stop();
}
