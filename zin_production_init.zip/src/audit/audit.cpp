
#include "audit.hpp"
#include <iostream>
namespace zin::audit {
bool init(){
    std::cout<<"[audit] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[audit] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[audit] stop"<<std::endl;
    return true;
}
}
