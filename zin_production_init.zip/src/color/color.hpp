
#pragma once
#include <string>
namespace zin::color {
bool init();
bool start();
bool stop();
}
