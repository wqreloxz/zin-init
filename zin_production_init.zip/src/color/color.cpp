
#include "color.hpp"
#include <iostream>
namespace zin::color {
bool init(){
    std::cout<<"[color] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[color] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[color] stop"<<std::endl;
    return true;
}
}
