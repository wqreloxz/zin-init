
#include "display.hpp"
#include <iostream>
namespace zin::display{
void init(){ std::cout<<"zin init boot"<<std::endl;}
void ok(const std::string&m){ std::cout<<"\033[32m"<<m<<"\033[0m"<<std::endl;}
void warn(const std::string&m){ std::cout<<"\033[33m"<<m<<"\033[0m"<<std::endl;}
void fail(const std::string&m){ std::cout<<"\033[31m"<<m<<"\033[0m"<<std::endl;}
}
