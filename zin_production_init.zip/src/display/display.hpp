
#pragma once
#include <string>
namespace zin::display{
void init();
void ok(const std::string&);
void warn(const std::string&);
void fail(const std::string&);
}
