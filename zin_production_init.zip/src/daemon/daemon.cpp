
#include "daemon.hpp"
#include <iostream>
namespace zin::daemon {
bool init(){
    std::cout<<"[daemon] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[daemon] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[daemon] stop"<<std::endl;
    return true;
}
}
