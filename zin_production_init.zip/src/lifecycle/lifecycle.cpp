
#include "lifecycle.hpp"
#include <unistd.h>
#include <sys/reboot.h>
namespace zin::lifecycle{
bool init(){return true;}
bool start(){return true;}
bool stop(){
    sync();
    reboot(RB_AUTOBOOT);
    return true;
}
}
