
#pragma once
#include <string>
namespace zin::lifecycle {
bool init();
bool start();
bool stop();
}
