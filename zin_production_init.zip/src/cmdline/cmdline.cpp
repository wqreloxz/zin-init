
#include "cmdline.hpp"
#include <iostream>
namespace zin::cmdline {
bool init(){
    std::cout<<"[cmdline] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[cmdline] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[cmdline] stop"<<std::endl;
    return true;
}
}
