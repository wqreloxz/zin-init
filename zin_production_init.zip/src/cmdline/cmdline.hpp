
#pragma once
#include <string>
namespace zin::cmdline {
bool init();
bool start();
bool stop();
}
