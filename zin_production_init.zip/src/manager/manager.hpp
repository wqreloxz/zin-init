
#pragma once
#include <string>
namespace zin::manager {
bool init();
bool start();
bool stop();
}
