
#include "manager.hpp"
#include <iostream>
namespace zin::manager {
bool init(){
    std::cout<<"[manager] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[manager] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[manager] stop"<<std::endl;
    return true;
}
}
