
#pragma once
#include <string>
namespace zin::signal {
bool init();
bool start();
bool stop();
}
