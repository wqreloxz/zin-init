
#include "signal.hpp"
#include <iostream>
namespace zin::signal {
bool init(){
    std::cout<<"[signal] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[signal] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[signal] stop"<<std::endl;
    return true;
}
}
