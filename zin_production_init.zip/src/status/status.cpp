
#include "status.hpp"
#include <iostream>
namespace zin::status {
bool init(){
    std::cout<<"[status] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[status] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[status] stop"<<std::endl;
    return true;
}
}
