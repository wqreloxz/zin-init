
#pragma once
#include <string>
namespace zin::status {
bool init();
bool start();
bool stop();
}
