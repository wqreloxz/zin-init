
#include "health.hpp"
#include <iostream>
namespace zin::health {
bool init(){
    std::cout<<"[health] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[health] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[health] stop"<<std::endl;
    return true;
}
}
