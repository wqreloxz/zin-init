
#pragma once
#include <string>
namespace zin::health {
bool init();
bool start();
bool stop();
}
