
#pragma once
#include <string>
namespace zin::dependency {
bool init();
bool start();
bool stop();
}
