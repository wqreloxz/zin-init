
#include "dependency.hpp"
#include <iostream>
namespace zin::dependency {
bool init(){
    std::cout<<"[dependency] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[dependency] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[dependency] stop"<<std::endl;
    return true;
}
}
