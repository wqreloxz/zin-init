
#pragma once
#include <string>
namespace zin::kernel {
bool init();
bool start();
bool stop();
}
