
#include "kernel.hpp"
#include <iostream>
namespace zin::kernel {
bool init(){
    std::cout<<"[kernel] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[kernel] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[kernel] stop"<<std::endl;
    return true;
}
}
