
#pragma once
#include <string>
namespace zin::overlay {
bool init();
bool start();
bool stop();
}
