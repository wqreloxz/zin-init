
#include "overlay.hpp"
#include <iostream>
namespace zin::overlay {
bool init(){
    std::cout<<"[overlay] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[overlay] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[overlay] stop"<<std::endl;
    return true;
}
}
