
#pragma once
#include <string>
namespace zin::toml {
bool init();
bool start();
bool stop();
}
