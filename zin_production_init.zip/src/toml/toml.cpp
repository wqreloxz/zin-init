
#include "toml.hpp"
#include <iostream>
namespace zin::toml {
bool init(){
    std::cout<<"[toml] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[toml] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[toml] stop"<<std::endl;
    return true;
}
}
