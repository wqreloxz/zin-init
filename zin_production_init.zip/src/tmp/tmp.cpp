
#include "tmp.hpp"
#include <iostream>
namespace zin::tmp {
bool init(){
    std::cout<<"[tmp] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[tmp] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[tmp] stop"<<std::endl;
    return true;
}
}
