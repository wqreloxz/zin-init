
#pragma once
#include <string>
namespace zin::tmp {
bool init();
bool start();
bool stop();
}
