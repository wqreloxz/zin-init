
#pragma once
#include <string>
namespace zin::tty {
bool init();
bool start();
bool stop();
}
