
#include "tty.hpp"
#include <unistd.h>
#include "../logger/logger.hpp"

namespace zin::tty{
bool init(){return true;}
bool start(){
    zin::logger::info("starting getty tty1");
    pid_t p=fork();
    if(p==0){
        execl("/sbin/getty","getty","tty1",nullptr);
        _exit(1);
    }
    return true;
}
bool stop(){return true;}
}
