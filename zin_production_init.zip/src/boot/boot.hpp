
#pragma once
#include <string>
namespace zin::boot {
bool init();
bool start();
bool stop();
}
