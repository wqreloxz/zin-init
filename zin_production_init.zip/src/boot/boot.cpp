
#include "boot.hpp"
#include <iostream>
namespace zin::boot {
bool init(){
    std::cout<<"[boot] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[boot] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[boot] stop"<<std::endl;
    return true;
}
}
