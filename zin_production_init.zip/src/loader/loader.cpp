
#include "loader.hpp"
#include <iostream>
namespace zin::loader {
bool init(){
    std::cout<<"[loader] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[loader] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[loader] stop"<<std::endl;
    return true;
}
}
