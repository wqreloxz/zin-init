
#pragma once
#include <string>
namespace zin::loader {
bool init();
bool start();
bool stop();
}
