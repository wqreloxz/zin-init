
#include "scheduler.hpp"
#include <iostream>
namespace zin::scheduler {
bool init(){
    std::cout<<"[scheduler] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[scheduler] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[scheduler] stop"<<std::endl;
    return true;
}
}
