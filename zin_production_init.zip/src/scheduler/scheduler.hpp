
#pragma once
#include <string>
namespace zin::scheduler {
bool init();
bool start();
bool stop();
}
