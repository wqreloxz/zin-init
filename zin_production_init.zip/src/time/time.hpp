
#pragma once
#include <string>
namespace zin::time {
bool init();
bool start();
bool stop();
}
