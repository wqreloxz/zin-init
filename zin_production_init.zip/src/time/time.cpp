
#include "time.hpp"
#include <iostream>
namespace zin::time {
bool init(){
    std::cout<<"[time] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[time] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[time] stop"<<std::endl;
    return true;
}
}
