
#include <iostream>
#include <unistd.h>
#include <csignal>
#include <sys/wait.h>

#include "logger/logger.hpp"
#include "mount/mount.hpp"
#include "service/service.hpp"
#include "tty/tty.hpp"
#include "lifecycle/lifecycle.hpp"
#include "fallback/fallback.hpp"
#include "state/state.hpp"
#include "profile/profile.hpp"
#include "display/display.hpp"
#include "kernel/kernel.hpp"

static bool running=true;

void sigchld(int){
    while(waitpid(-1,nullptr,WNOHANG)>0){}
}
void shutdown(int){
    running=false;
}

int main(){
    if(getpid()!=1){
        std::cout<<"[zin] warning: not pid1"<<std::endl;
    }

    signal(SIGCHLD,sigchld);
    signal(SIGINT,shutdown);
    signal(SIGTERM,shutdown);

    zin::display::init();
    zin::logger::init();
    zin::fallback::init();
    zin::kernel::init();
    zin::mount::init();
    zin::state::init();
    zin::profile::init();
    zin::service::start();
    zin::tty::start();

    zin::display::ok("system booted");

    while(running){
        pause();
    }

    zin::lifecycle::stop();
    return 0;
}
