
#pragma once
#include <string>
namespace zin::history {
bool init();
bool start();
bool stop();
}
