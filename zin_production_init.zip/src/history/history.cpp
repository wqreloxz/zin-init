
#include "history.hpp"
#include <iostream>
namespace zin::history {
bool init(){
    std::cout<<"[history] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[history] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[history] stop"<<std::endl;
    return true;
}
}
