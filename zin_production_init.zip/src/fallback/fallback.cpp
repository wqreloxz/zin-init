
#include "fallback.hpp"
#include <iostream>
namespace zin::fallback {
bool init(){
    std::cout<<"[fallback] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[fallback] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[fallback] stop"<<std::endl;
    return true;
}
}
