
#pragma once
#include <string>
namespace zin::fallback {
bool init();
bool start();
bool stop();
}
