
#pragma once
#include <string>
namespace zin::rollback {
bool init();
bool start();
bool stop();
}
