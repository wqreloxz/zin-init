
#include "rollback.hpp"
#include <iostream>
namespace zin::rollback {
bool init(){
    std::cout<<"[rollback] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[rollback] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[rollback] stop"<<std::endl;
    return true;
}
}
