
#pragma once
#include <string>
namespace zin::ipc {
bool init();
bool start();
bool stop();
}
