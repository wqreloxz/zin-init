
#include "ipc.hpp"
#include <iostream>
namespace zin::ipc {
bool init(){
    std::cout<<"[ipc] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[ipc] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[ipc] stop"<<std::endl;
    return true;
}
}
