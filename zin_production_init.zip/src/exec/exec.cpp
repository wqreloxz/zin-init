
#include "exec.hpp"
#include <iostream>
namespace zin::exec {
bool init(){
    std::cout<<"[exec] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[exec] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[exec] stop"<<std::endl;
    return true;
}
}
