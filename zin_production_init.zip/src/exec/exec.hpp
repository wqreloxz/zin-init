
#pragma once
#include <string>
namespace zin::exec {
bool init();
bool start();
bool stop();
}
