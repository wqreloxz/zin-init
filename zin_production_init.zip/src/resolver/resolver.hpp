
#pragma once
#include <string>
namespace zin::resolver {
bool init();
bool start();
bool stop();
}
