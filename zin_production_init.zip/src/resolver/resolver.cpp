
#include "resolver.hpp"
#include <iostream>
namespace zin::resolver {
bool init(){
    std::cout<<"[resolver] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[resolver] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[resolver] stop"<<std::endl;
    return true;
}
}
