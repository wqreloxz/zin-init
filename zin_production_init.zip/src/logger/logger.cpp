
#include "logger.hpp"
#include <fstream>
#include <iostream>
static std::ofstream f;

static void out(const std::string&c,const std::string&m){
    std::cout<<c<<m<<"\033[0m"<<std::endl;
    if(f.is_open()) f<<m<<std::endl;
}
namespace zin::logger{
void init(){ f.open("/var/log/zin.log",std::ios::app); }
void info(const std::string&m){ out("\033[36m",m);}
void warn(const std::string&m){ out("\033[33m",m);}
void err(const std::string&m){ out("\033[31m",m);}
void ok(const std::string&m){ out("\033[32m",m);}
}
