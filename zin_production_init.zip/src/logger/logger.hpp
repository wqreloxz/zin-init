
#pragma once
#include <string>
namespace zin::logger{
void init();
void info(const std::string&);
void warn(const std::string&);
void err(const std::string&);
void ok(const std::string&);
}
