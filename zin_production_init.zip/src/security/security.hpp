
#pragma once
#include <string>
namespace zin::security {
bool init();
bool start();
bool stop();
}
