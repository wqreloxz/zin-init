
#include "security.hpp"
#include <iostream>
namespace zin::security {
bool init(){
    std::cout<<"[security] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[security] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[security] stop"<<std::endl;
    return true;
}
}
