
#include "unit.hpp"
#include <iostream>
namespace zin::unit {
bool init(){
    std::cout<<"[unit] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[unit] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[unit] stop"<<std::endl;
    return true;
}
}
