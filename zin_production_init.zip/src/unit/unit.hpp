
#pragma once
#include <string>
namespace zin::unit {
bool init();
bool start();
bool stop();
}
