
#pragma once
#include <string>
namespace zin::mount {
bool init();
bool start();
bool stop();
}
