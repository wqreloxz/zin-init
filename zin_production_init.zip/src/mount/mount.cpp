
#include "mount.hpp"
#include "../logger/logger.hpp"
#include <sys/mount.h>

namespace zin::mount{
bool init(){
    mount("proc","/proc","proc",0,"");
    mount("sysfs","/sys","sysfs",0,"");
    mount("devtmpfs","/dev","devtmpfs",0,"");
    zin::logger::ok("virtual fs mounted");
    return true;
}
bool start(){return true;}
bool stop(){return true;}
}
