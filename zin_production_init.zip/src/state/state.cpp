
#include "state.hpp"
#include <iostream>
namespace zin::state {
bool init(){
    std::cout<<"[state] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[state] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[state] stop"<<std::endl;
    return true;
}
}
