
#include "config.hpp"
#include <iostream>
namespace zin::config {
bool init(){
    std::cout<<"[config] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[config] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[config] stop"<<std::endl;
    return true;
}
}
