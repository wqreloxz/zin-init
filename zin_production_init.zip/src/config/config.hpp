
#pragma once
#include <string>
namespace zin::config {
bool init();
bool start();
bool stop();
}
