
#pragma once
#include <string>
namespace zin::swap {
bool init();
bool start();
bool stop();
}
