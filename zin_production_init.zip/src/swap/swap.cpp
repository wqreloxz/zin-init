
#include "swap.hpp"
#include <iostream>
namespace zin::swap {
bool init(){
    std::cout<<"[swap] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[swap] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[swap] stop"<<std::endl;
    return true;
}
}
