
#pragma once
#include <string>
namespace zin::fs {
bool init();
bool start();
bool stop();
}
