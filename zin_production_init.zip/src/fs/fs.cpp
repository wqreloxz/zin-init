
#include "fs.hpp"
#include <iostream>
namespace zin::fs {
bool init(){
    std::cout<<"[fs] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[fs] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[fs] stop"<<std::endl;
    return true;
}
}
