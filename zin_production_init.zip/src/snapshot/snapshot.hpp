
#pragma once
#include <string>
namespace zin::snapshot {
bool init();
bool start();
bool stop();
}
