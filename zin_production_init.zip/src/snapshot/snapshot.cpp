
#include "snapshot.hpp"
#include <iostream>
namespace zin::snapshot {
bool init(){
    std::cout<<"[snapshot] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[snapshot] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[snapshot] stop"<<std::endl;
    return true;
}
}
