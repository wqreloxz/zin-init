
#include "persist.hpp"
#include <iostream>
namespace zin::persist {
bool init(){
    std::cout<<"[persist] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[persist] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[persist] stop"<<std::endl;
    return true;
}
}
