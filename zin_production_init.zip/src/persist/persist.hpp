
#pragma once
#include <string>
namespace zin::persist {
bool init();
bool start();
bool stop();
}
