
#include "panicless.hpp"
#include <iostream>
namespace zin::panicless {
bool init(){
    std::cout<<"[panicless] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[panicless] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[panicless] stop"<<std::endl;
    return true;
}
}
