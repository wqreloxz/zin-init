
#pragma once
#include <string>
namespace zin::panicless {
bool init();
bool start();
bool stop();
}
