
#include "translator.hpp"
#include <iostream>
namespace zin::translator {
bool init(){
    std::cout<<"[translator] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[translator] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[translator] stop"<<std::endl;
    return true;
}
}
