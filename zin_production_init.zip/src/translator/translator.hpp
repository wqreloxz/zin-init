
#pragma once
#include <string>
namespace zin::translator {
bool init();
bool start();
bool stop();
}
