
#pragma once
#include <string>
namespace zin::hostname {
bool init();
bool start();
bool stop();
}
