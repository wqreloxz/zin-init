
#include "hostname.hpp"
#include <iostream>
namespace zin::hostname {
bool init(){
    std::cout<<"[hostname] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[hostname] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[hostname] stop"<<std::endl;
    return true;
}
}
