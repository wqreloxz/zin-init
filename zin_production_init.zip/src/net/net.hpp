
#pragma once
#include <string>
namespace zin::net {
bool init();
bool start();
bool stop();
}
