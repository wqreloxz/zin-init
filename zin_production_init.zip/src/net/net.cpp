
#include "net.hpp"
#include <iostream>
namespace zin::net {
bool init(){
    std::cout<<"[net] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[net] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[net] stop"<<std::endl;
    return true;
}
}
