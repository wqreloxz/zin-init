
#pragma once
#include <string>
namespace zin::service {
bool init();
bool start();
bool stop();
}
