
#include "service.hpp"
#include "../logger/logger.hpp"
#include <unistd.h>
#include <sys/types.h>

namespace zin::service{
bool init(){return true;}
bool start(){
    zin::logger::info("starting basic services");

    pid_t p=fork();
    if(p==0){
        execl("/sbin/udevd","udevd",nullptr);
        _exit(1);
    }
    return true;
}
bool stop(){return true;}
}
