
#pragma once
#include <string>
namespace zin::parser {
bool init();
bool start();
bool stop();
}
