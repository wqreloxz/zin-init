
#include "parser.hpp"
#include <iostream>
namespace zin::parser {
bool init(){
    std::cout<<"[parser] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[parser] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[parser] stop"<<std::endl;
    return true;
}
}
