
#include "memory.hpp"
#include <iostream>
namespace zin::memory {
bool init(){
    std::cout<<"[memory] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[memory] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[memory] stop"<<std::endl;
    return true;
}
}
