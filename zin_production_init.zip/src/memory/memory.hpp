
#pragma once
#include <string>
namespace zin::memory {
bool init();
bool start();
bool stop();
}
