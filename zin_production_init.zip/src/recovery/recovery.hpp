
#pragma once
#include <string>
namespace zin::recovery {
bool init();
bool start();
bool stop();
}
