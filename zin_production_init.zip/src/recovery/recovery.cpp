
#include "recovery.hpp"
#include <iostream>
namespace zin::recovery {
bool init(){
    std::cout<<"[recovery] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[recovery] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[recovery] stop"<<std::endl;
    return true;
}
}
