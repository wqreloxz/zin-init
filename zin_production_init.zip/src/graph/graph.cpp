
#include "graph.hpp"
#include <iostream>
namespace zin::graph {
bool init(){
    std::cout<<"[graph] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[graph] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[graph] stop"<<std::endl;
    return true;
}
}
