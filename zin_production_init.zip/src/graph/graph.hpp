
#pragma once
#include <string>
namespace zin::graph {
bool init();
bool start();
bool stop();
}
