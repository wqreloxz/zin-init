
#pragma once
#include <string>
namespace zin::env {
bool init();
bool start();
bool stop();
}
