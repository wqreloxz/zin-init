
#include "env.hpp"
#include <iostream>
namespace zin::env {
bool init(){
    std::cout<<"[env] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[env] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[env] stop"<<std::endl;
    return true;
}
}
