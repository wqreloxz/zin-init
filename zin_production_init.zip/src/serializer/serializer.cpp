
#include "serializer.hpp"
#include <iostream>
namespace zin::serializer {
bool init(){
    std::cout<<"[serializer] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[serializer] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[serializer] stop"<<std::endl;
    return true;
}
}
