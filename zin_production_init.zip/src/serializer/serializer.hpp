
#pragma once
#include <string>
namespace zin::serializer {
bool init();
bool start();
bool stop();
}
