
#include "process.hpp"
#include <iostream>
namespace zin::process {
bool init(){
    std::cout<<"[process] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[process] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[process] stop"<<std::endl;
    return true;
}
}
