
#pragma once
#include <string>
namespace zin::process {
bool init();
bool start();
bool stop();
}
