
#include "profile.hpp"
#include "../logger/logger.hpp"
#include <fstream>
namespace zin::profile{
bool init(){
    std::ifstream f("/etc/zin/init.toml");
    std::string s;
    while(std::getline(f,s)){
        if(s.find("__init__")!=std::string::npos){
            zin::logger::info("profile line: "+s);
        }
    }
    return true;
}
bool start(){return true;}
bool stop(){return true;}
}
