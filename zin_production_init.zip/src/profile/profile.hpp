
#pragma once
#include <string>
namespace zin::profile {
bool init();
bool start();
bool stop();
}
