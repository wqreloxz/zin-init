
#pragma once
#include <string>
namespace zin::core {
bool init();
bool start();
bool stop();
}
