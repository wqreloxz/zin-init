
#include "core.hpp"
#include <iostream>
namespace zin::core {
bool init(){
    std::cout<<"[core] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[core] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[core] stop"<<std::endl;
    return true;
}
}
