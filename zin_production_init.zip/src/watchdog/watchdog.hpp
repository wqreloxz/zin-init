
#pragma once
#include <string>
namespace zin::watchdog {
bool init();
bool start();
bool stop();
}
