
#include "watchdog.hpp"
#include <iostream>
namespace zin::watchdog {
bool init(){
    std::cout<<"[watchdog] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[watchdog] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[watchdog] stop"<<std::endl;
    return true;
}
}
