
#include "device.hpp"
#include <iostream>
namespace zin::device {
bool init(){
    std::cout<<"[device] init"<<std::endl;
    return true;
}
bool start(){
    std::cout<<"[device] start"<<std::endl;
    return true;
}
bool stop(){
    std::cout<<"[device] stop"<<std::endl;
    return true;
}
}
