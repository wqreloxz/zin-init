
#pragma once
#include <string>
namespace zin::device {
bool init();
bool start();
bool stop();
}
