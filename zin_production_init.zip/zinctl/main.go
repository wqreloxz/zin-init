
package main
import(
"fmt"
"os"
)
func main(){
if len(os.Args)<2{
fmt.Println("zinctl status|reboot")
return
}
switch os.Args[1]{
case "status":
fmt.Println("zin running")
case "reboot":
fmt.Println("reboot signal sent")
default:
fmt.Println("unknown")
}
}
